from aiogram.types import KeyboardButton, ReplyKeyboardMarkup

main_menu = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="🧘 Описание Анжелики"),
            KeyboardButton(text="📅 Записаться"),
        ],
        [
            KeyboardButton(text="💳 Оплата подписки"),
            KeyboardButton(text="🧾 Статус подписки"),
        ],
        [
            KeyboardButton(text="❓ Задать вопрос"),
        ],
    ],
    resize_keyboard=True,
    input_field_placeholder="Выберите действие",
)
