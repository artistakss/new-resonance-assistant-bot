from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.types import Message

from app.database import repository
from app.keyboards.main import main_menu

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message) -> None:
    user = message.from_user
    await repository.upsert_user(user.id, user.username, user.full_name)
    await message.answer(
        "🧘‍♀️ Добро пожаловать в Resonance Assistant!\n\n"
        "Я помогу попасть в закрытый канал, продлить подписку и записаться на консультацию к Анжелике.",
        reply_markup=main_menu,
    )


@router.message(F.text == "🧘 Описание Анжелики")
async def describe(message: Message) -> None:
    await message.answer(
        "✨ Анжелика — эксперт по эмоциональному балансу и осознанности."
        " Проводит личные онлайн и офлайн сессии, ведёт резиденцию Resonance."
    )


@router.message(F.text == "❓ Задать вопрос")
async def ask_question(message: Message) -> None:
    await message.answer(
        "Напишите ваш вопрос в свободной форме."
        " Администратор свяжется с вами в течение дня."
    )
